#include "missing.h"

int main()
{
    int x;
    x++;
}
